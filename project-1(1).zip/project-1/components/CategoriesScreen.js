import React, { useState } from 'react';
import { StyleSheet, Text, View, Button, FlatList, TouchableOpacity, Image, ImageBackground, } from 'react-native';

const categories = {
  "Amitié": [
    {
      content:
        'Il n’y a point d’amitié plus douce que celle qui naît de la sympathies des caractères.',
      author: 'Cicéron',
      background: require('../assets/amitié9.jpeg'),
    },
    {
      content:
        'Quel que soit le chemin, quel que soit l’avenir, le seul guide en ce monde est la main d’une amie.',
      author: 'Alfred de Musset',
      background: require('../assets/amitié6.jpeg'),
    },
    {
      content: 'Il ne vaut pas la peine, si l’on n’a pas un bon ami.',
      author: 'Démocrite',
      background: require('../assets/amitié5.jpeg'),
    },
    {
      content: 'Un ami est un frère que nous avons choisi.',
      author: 'Joseph Droz',
      background: require('../assets/amitié1.jpeg'),
    },
    {
      content: 'L’amitié ne meurt jamais dans un bon cœur.',
      author: 'Pierre-Claude-Victor Boiste',
      background: require('../assets/amitié2.jpeg'),
    },
    {
      content:
        'L’amitié est toujours une douce responsabilité, jamais une opportunité.',
      author: 'Khalil Gibran',
      background: require('../assets/amitié7.jpeg'),
    },
    {
      content:
        'L’amour comme l’amitié se nourrit seulement de surmonter, de pardonner et de permettre.',
      author: 'Alain',
      background: require('../assets/amitié4.jpeg'),
    },
    {
      content:
        'L’amitié adoucit toutes les douleurs et redouble tous les plaisirs.',
      author: 'Madeleine de Scudery',
      background: require('../assets/amitié8.jpeg'),
    },
    {
      content: 'On voit qu’un ami est sûr quand notre situation ne l’est pas.',
      author: 'Cicéron',
      background: require('../assets/amour3.jpeg'),
    },
  ],
  "Amour": [
    {
      content: "L'amour est l'espace et le temps rendus sensibles au cœur.",
      author: 'Marcel proust',
      background: require('../assets/images.jpeg'),
    },
    {
      content: 'L’homme est grand lorsqu’il aime.',
      author: 'Louise Ackermann',
      background: require('../assets/amour5.jpeg'),
    },
    {
      content:
        'Il faut à l’amour, comme à tout ce qui est durable, l’océan de l’éternité.',
      author: 'Henri Larcodaire',
      background: require('../assets/amour4.jpeg'),
    },
    {
      content:
        'L’homme ne peut vivre sans amour; sans amour, la vie est une anticipation de la mort.',
      author: 'Pierre-Joseph Proudhon',
      background: require('../assets/amour3.jpeg'),
    },
    {
      content:
        'Il n’y a rien qui nous transforme autant que l’amour. Quand on aime, la vie est belle.',
      author: 'Victor Cherbuliez',
      background: require('../assets/amour2.jpeg'),
    },
    {
      content: 'Où il n’y a pas d’amour, il n’y a pas de sagesse.',
      author: 'Fiodor Dostoïevski',
      background: require('../assets/amour1.jpeg'),
    },
    {
      content: 'Quand on est amoureux, nuit et jour on n’a aucun repos.',
      author: 'Molière',
      background: require('../assets/amour6.jpeg'),
    },
    {
      content: 'L’amour ne se voit pas avec les yeux mais avec l’âme.',
      author: 'Shakespare',
      background: require('../assets/amour8.jpeg'),
    },
    {
      content:
        'Il n’est qu’un bonheur sur la terre, celui d’amer et d’être aimé.',
      author: 'Félix Arvers',
      background: require('../assets/amour7.jpeg'),
    },
  ],
  background : require('../assets/am.jpeg'),
  "colère": [
    {
      content:
        'La colère vide l’âme de toutes ses ressources, de sorte qu’au fond paraît la lumière.',
      author: 'Friedrich Nietzsche',
      background: require('../assets/1.jpg'),
    },
    {
      content: 'La colère est aveugle.',
      author: 'Proverbe Français',
      background: require('../assets/2.jpg'),
    },
    {
      content: 'Prenez garde à la colère d’un homme patient.',
      author: 'John Dryden',
      background: require('../assets/3.jpg'),
    },
    {
      content: 'Vaincre la colère, c’est triompher de son plus grand ennemi.',
      author: 'Publius Syrus',
      background: require('../assets/4.jpg'),
    },
    {
      content: 'Une femme en est une guêpe piquante.',
      author: 'Nicholas Breton',
      background: require('../assets/5.jpg'),
    },
    {
      content: 'Une colère justifiée est toujours saine.',
      author: 'Paul Michaud',
      background: require('../assets/6.jpg'),
    },
    {
      content:
        'La colère est comme l’alcool: à petites doses et de temps en temps, cela peut rendre service.',
      author: 'Robert Escarpit',
      background: require('../assets/7.jpg'),
    },
    {
      content: 'L’humour est presque toujours la colère maquillée.',
      author: 'Stephen King',
      background: require('../assets/8.jpg'),
    },
    {
      content: 'Ça s’épuise vite, une colère de mère.',
      author: 'François Gravel',
      background: require('../assets/9.jpg'),
    },
  ],
  background : require('../assets/colère.jpeg'),
  "Confiance": [
    {
      content: 'Aie confiance en toi-même, tu sauras vivre.',
      author: 'Johann Wolfgang Von Goethe',
      background: require('../assets/10.jpg'),
    },
    {
      content: 'Qui a confiance en soit conduit les autres.',
      author: 'Horace',
      background: require('../assets/11.jpg'),
    },
    {
      content: 'La confiance et défiance sont également la ruine des hommes.',
      author: 'Hesiode',
      background: require('../assets/12.jpg'),
    },
    {
      content:
        'La confiance est un élément majeur. Sans elle, aucun projet n’aboutit.',
      author: 'Eric Tabarly',
      background: require('../assets/13.jpg'),
    },
    {
      content: 'La confiance est une possibilité divine de l’homme.',
      author: 'Henry de Montherlant',
      background: require('../assets/14.jpg'),
    },
    {
      content:
        'Si vous avez confiance en vous-mêmes, vous inspirerez confiance aux autres.',
      author: 'Johann Wolfgang Von Goethe',
      background: require('../assets/15.jpg'),
    },
    {
      content: 'La confiance est souvent une force de la force de la paresse.',
      author: 'Fernand Vandérand',
      background: require('../assets/16.jpg'),
    },
    {
      content: 'Rien comme la confiance pour conjurer le sort !',
      author: 'Renée Garneau',
      background: require('../assets/17.jpg'),
    },
    {
      content: 'La fin du monde, c’est quand on cesse d’avoir confiance.',
      author: 'Madeleine Oulette-Michalsa',
      background: require('../assets/18.jpg'),
    },
  ],
  background : require('../assets/confiance.jpeg'),
  "Courage": [
    {
      content: 'La fortune aide les courageux.',
      author: 'Térence',
      background: require('../assets/19.jpg'),
    },
    {
      content: 'On ne peut faire semblant d’être courageux.',
      author: 'Napoléon Bonaparte',
      background: require('../assets/20.jpg'),
    },
    {
      content:
        'Le véritable courage consiste à être courageux précisement quand on ne l’est pas.',
      author: 'Jules Renard',
      background: require('../assets/21.jpg'),
    },
    {
      content:
        'En général, les gens intelligents ne sont pas courageux et les gens courageux ne sont pas intelligents.',
      author: 'Charles de Gaules',
      background: require('../assets/22.jpg'),
    },
    {
      content:
        'Le lâche meurt plusieurs fois par jour, l’homme courageux ne meurt qu’une fois.',
      author: 'Giovanni Falcone',
      background: require('../assets/23.jpg'),
    },
    {
      content:
        'Rien n’est éternel sauf, chez l’homme courageux, le goût de la liberté.',
      author: 'Armand Salacrou',
      background: require('../assets/24.jpg'),
    },
    {
      content:
        'Un homme courageux vous tue avec une épée, un lâche avec un baiser.',
      author: 'Bob Dylan',
      background: require('../assets/25.jpg'),
    },
    {
      content:
        'L’homme courageux n’est pas celui qui n’a jamais peur, mais celui qui accepte de faire silence en lui.',
      author: 'Henri d’Hellencourt',
      background: require('../assets/26.jpg'),
    },
    {
      content: 'La vie est une question de choix, alors faites les bons choix.',
      author: 'Oscar Wilde',
      background: require('../assets/27.jpg'),
    },
  ],
  background : require('../assets/courage.jpeg'),
  "Echec": [
    {
      content: 'Le succès, c’est l’échec de l’échec.',
      author: 'Delphine Lamotte',
      background: require('../assets/28.jpg'),
    },
    {
      content:
        'L’échec fait partie intégrante de notre réussite. L’échec, c’est l’envers de la réussite.',
      author: 'Adonis',
      background: require('../assets/29.jpg'),
    },
    {
      content:
        'La pire erreur n’est pas dans l’échec mais dans l’incapacité de dominer l’échec.',
      author: 'François Mitterrand',
      background: require('../assets/30.jpg'),
    },
    {
      content:
        'Le succès c’est d’aller d’échec en échec sans perdre son enthousiasme.',
      author: 'Winston Churchill',
      background: require('../assets/31.jpg'),
    },
    {
      content: 'La hâte est la mère de l’échec.',
      author: 'Hérodote',
      background: require('../assets/32.jpg'),
    },
    {
      content: 'Les échecs servent de répétitions au succès.',
      author: 'Reed Cathy',
      background: require('../assets/33.jpg'),
    },
    {
      content: 'L’échec est le fondement de la réussite.',
      author: 'Lao-Tseu',
      background: require('../assets/34.jpg'),
    },
    {
      content: 'L’échec est un éternel gage de réussite.',
      author: 'Benoît Gagnon',
      background: require('../assets/35.jpg'),
    },
    {
      content: "Je ne perds jamais. Soit je gagne, soit j'apprends.",
      author: 'Nelson Mandela',
      background: require('../assets/36.jpg'),
    },
  ],
  background : require('../assets/echec.jpeg'),
  "Inspiration": [
    {
      content: 'L’inspiration vient en travaillant.',
      author: 'Dominique Glocheux',
      background: require('../assets/37.jpg'),
    },
    {
      content:
        "L'inspiration existe, mais elle doit te trouver en train de travailler.",
      author: 'Pablo Picasso',
      background: require('../assets/38.jpg'),
    },
    {
      content: "La créativité, c'est l'intelligence qui s'amuse.",
      author: 'Albert Einstein',
      background: require('../assets/39.jpg'),
    },
    {
      content:
        'Vous ne pouvez pas épuiser la créativité. Plus vous l’utilisez, plus vous en avez.',
      author: 'Maya Angelou',
      background: require('../assets/40.jpg'),
    },
    {
      content:
        'Les deux jours les plus importants de votre vie sont le jour où vous êtes né et le jour où vous découvrez pourquoi.',
      author: 'Mark Twain',
      background: require('../assets/41.jpg'),
    },
    {
      content:
        'La liberté est la première des sources d’inspirations pour un créatif.',
      author: 'Nino Cerruti',
      background: require('../assets/42.jpg'),
    },
    {
      content:
        'C’est dans les rêves que loge l’inspiration, la graine des chefs-d’oeuvres de l’humanité.',
      author: 'Micheline la France',
      background: require('../assets/43.jpg'),
    },
    {
      content:
        'Rien ne sert de courir après l’inspiration, elle vient à point qui sait la chauffer.',
      author: 'André Brochon',
      background: require('../assets/44.jpg'),
    },
    {
      content: 'L’inspiration du moment vaut l’expérience d’une vie.',
      author: 'Olivier Wendell Holmes',
      background: require('../assets/45.jpg'),
    },
  ],
  background : require('../assets/inspiration.jpeg'),
  "Motivation": [
    {
      content: "Cela semble toujours impossible jusqu'à ce que ce soit fait.",
      author: 'Nelson Mandela',
      background: require('../assets/46.jpg'),
    },
    {
      content:
        "La différence entre une personne qui réussit et les autres, ce n'est pas  un manque de force, ni un manque de connaissance, mais plutôt un manque  de volonté.",
      author: 'Vince Lombardi',
      background: require('../assets/47.jpg'),
    },
    {
      content:
        'La seule limite à votre impact est votre imagination et votre engagement.',
      author: 'Tony Robbins',
      background: require('../assets/48.jpg'),
    },
    {
      content:
        "La plus grande gloire n'est pas de ne jamais tomber, mais de se relever à chaque chute.",
      author: 'Conficius',
      background: require('../assets/49.jpg'),
    },
    {
      content: "Ce que l'esprit peut concevoir et croire, il peut le réaliser.",
      author: 'Napoléon Hill',
      background: require('../assets/50.jpg'),
    },
    {
      content:
        'Un voyage de mille lieues commence toujours par un premier pas.',
      author: 'Lao-Tseu',
      background: require('../assets/51.jpg'),
    },
    {
      content:
        'Visez toujours la lune. Même si vous la manquez, vous atterrirez parmi les étoiles.',
      author: 'Les Brown',
      background: require('../assets/52.jpg'),
    },
    {
      content:
        "Vous n'avez pas besoin d'être grand pour commencer, mais vous devez commencer pour être grand.",
      author: 'Zig Ziglar',
      background: require('../assets/53.jpg'),
    },
    {
      content:
        'Votre attitude, plus que votre aptitude, déterminera votre altitude.',
      author: 'Zig Ziglar',
      background: require('../assets/54.jpg'),
    },
  ],
  background : require('../assets/motivation.jpeg'),
  "Respect": [
    {
      content: 'Le respect est la base de toute relation saine et authentique.',
      author: 'Anonyme',
      background: require('../assets/55.jpg'),
    },
    {
      content:
        "Le respect est l'attitude qui nous permet de voir les autres tels qu'ils sont, sans les juger ni les condamner.",
      author: 'Wayne Dyer',
      background: require('../assets/56.jpg'),
    },
    {
      content:
        'Le respect commence là où commence la compréhension des différences.',
      author: 'Anonyme',
      background: require('../assets/57.jpg'),
    },
    {
      content:
        'Le respect mutuel implique la discrétion et la capacité de comprendre les différences.',
      author: 'Lao-Tseu',
      background: require('../assets/58.jpg'),
    },
    {
      content:
        'Le respect est comme un miroir, plus tu le montres aux autres, plus il te reflète.',
      author: 'Anonyme',
      background: require('../assets/59.jpg'),
    },
    {
      content: 'Le respect ne vaut pas la soumission.',
      author: 'Zhang Xianliang',
      background: require('../assets/60.jpg'),
    },
    {
      content: 'Le secret de l’éducation réside dans le respect de l’élève.',
      author: 'Ralph Waldo Emerson',
      background: require('../assets/61.jpg'),
    },
    {
      content: 'Le respect de soi permet d’en avoir pour les autres.',
      author: 'José Garcia',
      background: require('../assets/62.jpg'),
    },
    {
      content:
        'Le devoir est la nécessité d’accomplir une action par respect pour la loi.',
      author: 'Emmanuel Kant',
      background: require('../assets/63.jpg'),
    },
  ],
  background : require('../assets/respect.jpeg'),
  "Sagesse": [
    {
      content: 'La seule vraie sagesse est de savoir que vous ne savez rien.',
      author: 'Socrate',
      background: require('../assets/64.jpg'),
    },
    {
      content: 'La vraie sagesse est de reconnaître sa propre ignorance.',
      author: 'Confucius',
      background: require('../assets/65.jpg'),
    },
    {
      content:
        "La sagesse est la lumière qui dissipe les ténèbres de l'ignorance.",
      author: 'Bouddha',
      background: require('../assets/66.jpg'),
    },
    {
      content:
        'La sagesse consiste à savoir que tout ce qui arrive est déjà arrivé avant.',
      author: 'Lao-Tseu',
      background: require('../assets/67.jpg'),
    },
    {
      content: "L'ignorant affirme, le savant doute, le sage réfléchit.",
      author: 'Confucius',
      background: require('../assets/70.jpg'),
    },
    {
      content: 'La sagesse est la partie la plus importante de la vertu.',
      author: 'Platon',
      background: require('../assets/71.jpg'),
    },
    {
      content:
        'La colère est comme l’alcool: à petites doses et de temps en temps, cela peut rendre service.',
      author: 'Robert Escarpit',
      background: require('../assets/72.jpg'),
    },
    {
      content: 'L’humour est presque toujours la colère maquillée.',
      author: 'Stephen King',
      background: require('../assets/73.jpg'),
    },
    {
      content: 'Ça s’épuise vite, une colère de mère.',
      author: 'François Gravel',
      background: require('../assets/74.jpg'),
    },
  ],
  background : require('../assets/sagesse.jpeg'),
  "Sérénité": [
    {
      content:
        "Lorsque j'ai l'esprit serein, c'est comme si j'étais un oiseau, libre et sans souci.",
      author: 'John Lennon',
      background: require('../assets/75.jpg'),
    },
    {
      content: "La véritable sérénité est en vous, non à l'extérieur.",
      author: 'Eckhart Tolle',
      background: require('../assets/76.jpg'),
    },
    {
      content: "La sérénité de l'esprit vient de la simplicité du cœur.",
      author: 'Dalaï Lama',
      background: require('../assets/77.jpg'),
    },
    {
      content:
        'La sérénité vient quand on échange les attentes contre l’acceptation.',
      author: 'Lao-Tseu',
      background: require('../assets/78.jpg'),
    },
    {
      content:
        "La paix vient de l'intérieur. Ne la cherchez pas à l'extérieur.",
      author: 'Bouddha',
      background: require('../assets/79.jpg'),
    },
    {
      content: "a paix vient de l'intérieur. Ne la cherchez pas à l'extérieur.",
      author: 'Thich Nhat Hanh',
      background: require('../assets/80.jpg'),
    },
    {
      content:
        "La vie, ce n'est pas d'attendre que les orages passent, c'est d'apprendre comment danser sous la pluie.",
      author: 'Sénèque',
      background: require('../assets/81.jpg'),
    },
    {
      content:
        "La tranquillité parfaite consiste dans le bon ordre de l'esprit, dans votre propre royaume.",
      author: 'Marc Aurèle',
      background: require('../assets/82.jpg'),
    },
    {
      content: "La mélancolie, c'est le bonheur d'être triste.",
      author: 'Victor Hugo',
      background: require('../assets/83.jpg'),
    },
  ],
  background : require('../assets/sérénité.jpeg'),
  "Succès": [
    {
      content: "Le succès, c'est 1% d'inspiration et 99% de transpiration.",
      author: 'Thomas Edison',
      background: require('../assets/84.jpg'),
    },
    {
      content:
        "Le succès consiste à obtenir ce que vous désirez. Le bonheur, c'est apprécier ce que vous obtenez.",
      author: 'Ralph Waldo Emerson',
      background: require('../assets/85.jpg'),
    },
    {
      content: 'Le succès vient à ceux qui deviennent conscients du succès.',
      author: 'Napoléon Hill',
      background: require('../assets/86.jpg'),
    },
    {
      content:
        "Il est bon de célébrer le succès, mais il est plus important de tirer les leçons de l'échec.",
      author: 'Bill Gates',
      background: require('../assets/87.jpg'),
    },
    {
      content:
        "Le succès est généralement l'aboutissement de ceux qui sont trop occupés pour chercher cela.",
      author: 'Nelson Mandela',
      background: require('../assets/88.jpg'),
    },
    {
      content: "Le succès est d'aimer la vie et d'oser en vivre les rêves.",
      author: 'Oprah Winfrey',
      background: require('../assets/89.jpg'),
    },
    {
      content:
        'Le prix du succès est le travail acharné, le dévouement à la tâche et la  détermination que, que nous gagnions ou que nous perdions, nous avons  appliqué de notre mieux.',
      author: 'Vince Lombardi',
      background: require('../assets/90.jpg'),
    },
    {
      content:
        "Le succès, c'est de rester fidèle à ses idéaux et à ses valeurs, même lorsque c'est difficile.",
      author: 'Nelson Mandela',
      background: require('../assets/91.jpg'),
    },
    {
      content:
        'N’essayez pas de devenir un homme qui a du succès. Essayez de devenir un homme qui a de la valeur.',
      author: 'Albert Einstein',
      background: require('../assets/92.jpg'),
    },
  ],
  background : require('../assets/succès.jpeg'),
};

const CategoriesScreen = ({ navigation }) => {
  const [selectedCategory, setSelectedCategory] = useState(null);

  const renderCategory = ({ item }) => (
  <TouchableOpacity
    style={styles.categoryButton}
    onPress={() => setSelectedCategory(item)}
  >
    <ImageBackground
      source={categories[item].background}
      style={styles.backgroundImage}
      imageStyle={{ borderRadius: 5 }}
    >
      <View style={styles.overlay}>
        <Text style={styles.categoryButtonText}>{item}</Text>
      </View>
    </ImageBackground>
  </TouchableOpacity>
);


  const renderQuote = ({ item }) => (
    <View style={styles.quoteContainer}>
      <Image source={item.background} style={styles.backgroundImage} />
      <View style={styles.quoteTextContainer}>
        <Text style={styles.quoteText}>{item.content}</Text>
        <Text style={styles.authorText}>- {item.author}</Text>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      {selectedCategory ? (
        <View style={styles.quoteListContainer}>
          <Button title="Retour" onPress={() => setSelectedCategory(null)} />
          <FlatList
            data={categories[selectedCategory]}
            renderItem={renderQuote}
            keyExtractor={(item, index) => index.toString()}
            numColumns={3}
            columnWrapperStyle={styles.columnWrapper}
          />
        </View>
      ) : (
        <View style={styles.categoryListContainer}>
          <FlatList
            data={Object.keys(categories)}
            renderItem={renderCategory}
            keyExtractor={(item, index) => index.toString()}
            numColumns={2}
            columnWrapperStyle={styles.columnWrapper}
          />
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  categoryButton: {
    width: '45%',
    height: 150,
    margin: 5,
    borderRadius: 5,
    overflow: 'hidden',
  },
  backgroundImage: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
  },
  categoryButtonText: {
    color: '#fff',
    fontSize: 18,
    textAlign: 'center',
    padding: 10,
  },
  quoteListContainer: {
    flex: 1,
    width: '100%',
  },
  quoteContainer: {
    flex: 1,
    alignItems: 'center',
    marginBottom: 20,
  },
  backgroundImage: {
    width: '100%',
    height: 200,
    borderRadius: 10,
  },
  quoteTextContainer: {
    position: 'absolute',
    bottom: 10,
    left: 10,
    right: 10,
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
  },
  quoteText: {
    color: '#fff',
    fontSize: 12,
    marginBottom: 5,
    fontFamily: 'Roboto serif'
  },
  authorText: {
    color: '#fff',
    fontSize: 12,
    textAlign: 'right',
    fontFamily: 'Rochester'
  },
});


export default CategoriesScreen;