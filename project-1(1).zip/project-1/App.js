import React, { useState, useEffect } from 'react';
import { TouchableOpacity, StyleSheet } from 'react-native';
import { SearchBar } from 'react-native-elements';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import HomeScreen from './components/HomeScreen';
import CategoriesScreen from './components/CategoriesScreen';
import FavoritesScreen from './components/FavoritesScreen';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

const styles = StyleSheet.create({
  searchBarContainer: {
    backgroundColor: '#0A0F29',
    borderBottomWidth: 0,
    borderTopWidth: 0,
  },
  searchBarInputContainer: {
    backgroundColor: '#182466',
    borderRadius: 50,
  },
  searchBarInput: {
    color: '#FFFFFF',
    fontFamily: 'Roboto',
    fontSize: 24,
  },
});

const HomeStack = ({ searchText, updateSearch, placeholder }) => (
  <Stack.Navigator>
    <Stack.Screen
      name="Home"
      component={HomeScreen}
      options={{
        header: () => (
          <SearchBar
            placeholder={placeholder}
            onChangeText={updateSearch}
            value={searchText}
            containerStyle={styles.searchBarContainer}
            inputContainerStyle={styles.searchBarInputContainer}
            inputStyle={styles.searchBarInput}
          />
        )
      }} // Masquer le titre de l'écran
    />
  </Stack.Navigator>
);

const CategoriesStack = ({ searchText, updateSearch, placeholder }) => (
  <Stack.Navigator>
    <Stack.Screen
      name="Categories"
      component={CategoriesScreen}
      options={{
        header: () => (
          <SearchBar
            placeholder={placeholder}
            onChangeText={updateSearch}
            value={searchText}
            containerStyle={styles.searchBarContainer}
            inputContainerStyle={styles.searchBarInputContainer}
            inputStyle={styles.searchBarInput}
          />
        )
      }} // Masquer le titre de l'écran
    />
  </Stack.Navigator>
);

const FavoritesStack = ({ searchText, updateSearch, placeholder }) => (
  <Stack.Navigator>
    <Stack.Screen
      name="Favorites"
      component={FavoritesScreen}
      options={{
        header: () => (
          <SearchBar
            placeholder={placeholder}
            onChangeText={updateSearch}
            value={searchText}
            containerStyle={styles.searchBarContainer}
            inputContainerStyle={styles.searchBarInputContainer}
            inputStyle={styles.searchBarInput}
          />
        )
      }} // Masquer le titre de l'écran
    />
  </Stack.Navigator>
);

export default function App() {
  const [searchText, setSearchText] = useState('');
  const [activeTab, setActiveTab] = useState('Home');
  const [placeholder, setPlaceholder] = useState('Home');

  const updateSearch = (text) => {
    setSearchText(text);
    // Ajoutez ici la logique pour filtrer vos données en fonction du texte de recherche
  };

  useEffect(() => {
    setSearchText(''); // Réinitialiser la barre de recherche à chaque changement d'onglet
    setPlaceholder(activeTab); // Mettre à jour le placeholder avec le nom de l'onglet actif
  }, [activeTab]);

  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          tabBarButton: (props) => (
            <TouchableOpacity
              {...props}
              onPress={() => {
                setActiveTab(route.name);
                props.onPress();
              }}
            />
          ),
        })}
      >
        <Tab.Screen name="Home">
          {() => <HomeStack searchText={searchText} updateSearch={updateSearch} placeholder={placeholder} />}
        </Tab.Screen>
        <Tab.Screen name="Categories">
          {() => <CategoriesStack searchText={searchText} updateSearch={updateSearch} placeholder={placeholder} />}
        </Tab.Screen>
        <Tab.Screen name="Favorites">
          {() => <FavoritesStack searchText={searchText} updateSearch={updateSearch} placeholder={placeholder} />}
        </Tab.Screen>
      </Tab.Navigator>
    </NavigationContainer>
  );
}
